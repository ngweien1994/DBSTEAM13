import React, { Component } from 'react';
import {Button} from 'primereact/button';
import logo from './logo.svg';
import './App.css';


class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
         
          <Button label="Save" />
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
          
          </a>
        </header>
        <Button label="Click" />
      </div>
    );
  }
}

export default App;
